
# app
from .compression_based import *  # noQA
from .edit_based import *  # noQA
from .phonetic import *  # noQA
from .sequence_based import *  # noQA
from .simple import *  # noQA
from .token_based import *  # noQA
