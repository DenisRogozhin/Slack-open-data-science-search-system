from ..en_PH import Provider as EnPhInternetProvider


class Provider(EnPhInternetProvider):
    """No difference from Internet Provider for en_PH locale"""

    pass
